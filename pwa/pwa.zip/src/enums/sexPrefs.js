export default [
	{
		value: 0,
		label: "Bi",
	},
	{
		value: 1,
		label: "Hetero",
	},
	{
		value: 2,
		label: "Homo",
	},
];