export default [
	{
		value: 0,
		label: "Male",
	},
	{
		value: 1,
		label: "Female",
	}
];